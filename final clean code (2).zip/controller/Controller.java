package controller;

import model.*;
import view.*;

import java.util.HashMap;
import java.util.regex.Matcher;

public class Controller {
    private final CustomerMenu customerMenu;
    private final LoginMenu loginMenu;
    private final MainMenu mainMenu;
    private final RestaurantAdminMenu restaurantAdminMenu;
    private final SnappfoodAdminMenu snappfoodAdminMenu;

    public Controller() {
        customerMenu = new CustomerMenu(this);
        loginMenu = new LoginMenu(this);
        mainMenu = new MainMenu(this);
        restaurantAdminMenu = new RestaurantAdminMenu(this);
        snappfoodAdminMenu = new SnappfoodAdminMenu(this);
    }


    public void run() {
        String usernameSnappFoodManager = Menu.usernameSnappFoodManager;
        String passwordSnappFoodManager = Menu.passwordSnappFoodManager;
        new SnappFoodManager(usernameSnappFoodManager, passwordSnappFoodManager);
        LoginMenu.allUsers.put(usernameSnappFoodManager, passwordSnappFoodManager);
        while (true) {
            if (loginMenu.run().equals("login successful")) {
                String outputMainMenu = mainMenu.run();
                if (outputMainMenu.equals("customer menu")) {
                    System.out.println("enter menu successful: You are in the customer menu!");
                    if (customerMenu.run().equals("logged out")) continue;
                } else if (outputMainMenu.equals("restaurant admin menu")) {
                    System.out.println("enter menu successful: You are in the restaurant admin menu!");
                    if (restaurantAdminMenu.run().equals("logged out")) continue;
                } else if (outputMainMenu.equals("Snappfood admin menu")) {
                    System.out.println("enter menu successful: You are in the Snappfood admin menu!");
                    if (snappfoodAdminMenu.run().equals("logged out")) continue;
                } else if (outputMainMenu.equals("logged out")) {
                    continue;
                }
            }
        }
    }

    // Login menu methods
    public void register(Matcher matcherRegister, HashMap<String,String> allUsers)
    {
        String username = matcherRegister.group(1);
        String password = matcherRegister.group(2);
        if (!Commands.getMatcher(username, Commands.USERNAME_VALIDATION).find())
            System.out.println("register failed: invalid username format");
        else if (allUsers.containsKey(username))
            System.out.println("register failed: username already exists");
        else if (!Commands.getMatcher(password, Commands.PASSWORD_VALIDATION).find())
            System.out.println("register failed: invalid password format");
        else if (!Commands.getMatcher(password, Commands.STRONG_PASSWORD).find())
            System.out.println("register failed: weak password");
        else {
            allUsers.put(username, password);
            new Customer(username, password);
            System.out.println("register successful");
        }
    }

    public String login(Matcher matcherLogin,HashMap<String,String> allUsers)
    {
        String username = matcherLogin.group(1);
        String password = matcherLogin.group(2);
        if (!allUsers.containsKey(username))
            System.out.println("login failed: username not found");
        else if (!allUsers.get(username).equals(password))
            System.out.println("login failed: incorrect password");
        else {
            System.out.println("login successful");
            return "login successful";
        }
        return null;
    }

    public void changePassword(Matcher matcherChangePassword,HashMap<String,String> allUsers)
    {
        String username = matcherChangePassword.group(1);
        String oldPassword = matcherChangePassword.group(2);
        String newPassword = matcherChangePassword.group(3);
        Matcher matcherUserValid = Commands.getMatcher(newPassword, Commands.PASSWORD_VALIDATION);
        Matcher matcherStrongPass = Commands.getMatcher(newPassword, Commands.STRONG_PASSWORD);
        if (!allUsers.containsKey(username))
            System.out.println("password change failed: username not found");
        else if (!allUsers.get(username).equals(oldPassword))
            System.out.println("password change failed: incorrect password");
        else if (!matcherUserValid.find())
            System.out.println("password change failed: invalid new password");
        else if (!matcherStrongPass.find())
            System.out.println("password change failed: weak new password");
        else {
            allUsers.remove(username);
            allUsers.put(username, newPassword);
            if (Customer.isUsernameCustomer(username))
                Customer.changePassword(username, newPassword);
            else if (username.equals(Menu.usernameSnappFoodManager))
                SnappFoodManager.changePassword(newPassword);
            else {
                RestaurantManager.ChangePassword(username, newPassword);
            }
            System.out.println("password change successful");
        }
    }

    public void removeAccount(Matcher matcherRemoveAccount,HashMap<String,String> allUsers)
    {
        String username = matcherRemoveAccount.group(1);
        String password = matcherRemoveAccount.group(2);
        if (!allUsers.containsKey(username))
            System.out.println("remove account failed: username not found");
        else if (!allUsers.get(username).equals(password))
            System.out.println("remove account failed: incorrect password");
        else {
            System.out.println("remove account successful");
            allUsers.remove(username, password);
            if (Customer.isUsernameCustomer(username))
                Customer.RemoveAccount(username);
            else {
                Restaurant.removeRestaurant(username);
                RestaurantManager.removeAccount(username);
            }
        }
    }

    //Main menu methods

    public String enterMenu(Matcher matcherEnter,String type)
    {
        String enterType = matcherEnter.group(1);
        if (!enterType.equals("customer menu") && !enterType.equals("restaurant admin menu") && !enterType.equals("Snappfood admin menu")) {
            System.out.println("enter menu failed: invalid menu name");
        } else if (!enterType.equals(type)) {
            System.out.println("enter menu failed: access denied");
        } else {
            return type;
        }
        return null;
    }

    public String usernameType()
    {
        String currentUsername = LoginMenu.currentUsername;
        String type;
        if (Customer.isUsernameCustomer(currentUsername)) {
            type = "customer menu";
        } else if (SnappFoodManager.manager.getUsername().equals(currentUsername)) {
            type = "Snappfood admin menu";
        } else {
            type = "restaurant admin menu";
        }
        return type;
    }

    //Customer menu methods

    public void chargeAccount(Matcher matcherChargeAccount,String currentUsername)
    {
        if (!Commands.getMatcher(matcherChargeAccount.group(1), Commands.IS_NUMBER).find())
            System.out.println("invalid command!");
        else {
            Integer amount = Integer.valueOf(matcherChargeAccount.group(1));
            if (amount <= 0)
                System.out.println("charge account failed: invalid cost or price");
            else {
                Customer.changeBalance(currentUsername, amount);
                System.out.println("charge account successful");
            }
        }
    }

    public void showBalance(String currentUsername)
    {
        Customer.showBalance(currentUsername);
    }

    public void showRestaurant(Matcher matcherShowRestaurant)
    {
        String type = matcherShowRestaurant.group(2);
        Customer.showRestaurants(type);
    }

    public void showMenu(Matcher matcherShowMenu)
    {
        String restaurantName = matcherShowMenu.group(1);
        String category = matcherShowMenu.group(3);
        if (Restaurant.findRestaurantByName(restaurantName) == null)
            System.out.println("show menu failed: restaurant not found");
        else {
            Customer.showMenu(Restaurant.findRestaurantByName(restaurantName), category);
        }
    }

    public void addToCart(Matcher matcherAddToCart,String currentUsername)
    {
        String restaurantName = matcherAddToCart.group(1);
        String foodName = matcherAddToCart.group(2);
        Integer numberOfOrder = 1;
        if (matcherAddToCart.group(4) != null)
            numberOfOrder = Integer.valueOf(matcherAddToCart.group(4));
        if (Restaurant.findRestaurantByName(restaurantName) == null)
            System.out.println("add to cart failed: restaurant not found");
        else if (Restaurant.findRestaurantByName(restaurantName).findFoodByName(foodName) == null)
            System.out.println("add to cart failed: food not found");
        else if (numberOfOrder <= 0)
            System.out.println("add to cart failed: invalid number");
        else {
            System.out.println("add to cart successful");
            Order order = new Order(Restaurant.findRestaurantByName(restaurantName), Restaurant.findRestaurantByName(restaurantName).findFoodByName(foodName), numberOfOrder);
            Customer.addToCart(currentUsername, order);
        }
    }

    public void removeFromCart(Matcher matcherRemoveFromCart,String currentUsername)
    {
        String restaurantName = matcherRemoveFromCart.group(1);
        String foodName = matcherRemoveFromCart.group(2);
        Integer numberOfOrder = 1;
        if (matcherRemoveFromCart.group(4) != null)
            numberOfOrder = Integer.valueOf(matcherRemoveFromCart.group(4));
        if (Customer.IsOrderInCart(currentUsername, restaurantName, foodName) == null)
            System.out.println("remove from cart failed: not in cart");
        else if (numberOfOrder <= 0)
            System.out.println("remove from cart failed: invalid number");
        else if (Customer.IsOrderInCart(currentUsername, restaurantName, foodName).getNumber() < numberOfOrder)
            System.out.println("remove from cart failed: not enough food in cart");
        else {
            System.out.println("remove from cart successful");
            Customer.removeFromCart(currentUsername, restaurantName, foodName, numberOfOrder);
        }
    }

    public void showCart(String currentUsername)
    {
        Customer.showCart(currentUsername);
    }
    public void showAllDiscount(String currentUsername)
    {
        Customer.showAllDiscount(currentUsername);
    }
    public void purchase(Matcher matcherPurchase,String currentUsername)
    {
        String discountCode = matcherPurchase.group(2);
        Customer.purchase(currentUsername, discountCode);
    }

    //Restaurant menu methods

    public void chargeRestaurantAccount(Matcher matcherChargeAccount,String currentUsername)
    {
        if (!Commands.getMatcher(matcherChargeAccount.group(1), Commands.IS_NUMBER).find())
            System.out.println("invalid command!");
        else {
            Integer amount = Integer.valueOf(matcherChargeAccount.group(1));
            if (amount <= 0)
                System.out.println("charge account failed: invalid cost or price");
            else {
                RestaurantManager.chargeAccount(currentUsername, amount);
                System.out.println("charge account successful");
            }
        }
    }
    public void showRestaurantBalance(String currentUsername)
    {
        RestaurantManager.showBalance(currentUsername);
    }
    public void addFood(Matcher matcherAddFood,String currentUsername)
    {
        String name = matcherAddFood.group(1);
        String category = matcherAddFood.group(2);
        if (!Commands.getMatcher(matcherAddFood.group(3), Commands.IS_NUMBER).find())
            System.out.println("invalid command!");
        else if (!Commands.getMatcher(matcherAddFood.group(4), Commands.IS_NUMBER).find())
            System.out.println("invalid command!");
        else {
            Integer price = Integer.valueOf(matcherAddFood.group(3));
            Integer cost = Integer.valueOf(matcherAddFood.group(4));
            if (!Commands.getMatcher(category, Commands.CATEGORY_VALIDATION).find())
                System.out.println("add food failed: invalid category");
            else if (!Commands.getMatcher(name, Commands.FOODNAME_VALIDATION).find())
                System.out.println("add food failed: invalid food name");
            else if (RestaurantManager.IsFoodAvailable(currentUsername, name))
                System.out.println("add food failed: food already exists");
            else if (price <= 0 || cost <= 0)
                System.out.println("add food failed: invalid cost or price");
            else {
                System.out.println("add food successful");
                RestaurantManager.addFood(currentUsername, name, category, cost, price);
            }
        }
    }
    public void removeFood(Matcher matcherRemoveFood,String currentUsername)
    {
        String name = matcherRemoveFood.group(1);
        RestaurantManager.removeFood(currentUsername, name);
    }

    //SnappFood Manager menu methods
    public void addRestaurant(Matcher matcherAddRestaurant)
    {
        String name = matcherAddRestaurant.group(1);
        String password = matcherAddRestaurant.group(2);
        String type = matcherAddRestaurant.group(3);
        if (!Commands.getMatcher(name, Commands.USERNAME_VALIDATION).find())
            System.out.println("add restaurant failed: invalid username format");
        else if (LoginMenu.allUsers.containsKey(name))
            System.out.println("add restaurant failed: username already exists");
        else if (!Commands.getMatcher(password, Commands.USERNAME_VALIDATION).find())
            System.out.println("add restaurant failed: invalid password format");
        else if (!Commands.getMatcher(password, Commands.STRONG_PASSWORD).find())
            System.out.println("add restaurant failed: weak password");
        else if (!Commands.getMatcher(type, Commands.TYPE_VALIDATION).find())
            System.out.println("add restaurant failed: invalid type format");
        else {
            Restaurant restaurant = new Restaurant(name, password, type);
            LoginMenu.allUsers.put(name, password);
            new RestaurantManager(restaurant, name, password);
            System.out.println("add restaurant successful");
        }
    }

    public void showRestaurantForManager(Matcher matcherShowRestaurant)
    {
        String type = matcherShowRestaurant.group(2);
        SnappFoodManager.showRestaurants(type);
    }

    public void removeRestaurant(Matcher matcherRemoveRestaurant)
    {
        String name = matcherRemoveRestaurant.group(1);
        if (Restaurant.getAllRestaurantsNames().contains(name)) {
            LoginMenu.allUsers.remove(name);
            Restaurant.removeRestaurant(name);
            RestaurantManager.removeAccount(name);
        } else {
            System.out.println("remove restaurant failed: restaurant not found");
        }
    }
    public void setDiscount(Matcher matcherSetDiscount)
    {
        String username = matcherSetDiscount.group(1);
        if (!Commands.getMatcher(matcherSetDiscount.group(2), Commands.IS_NUMBER).find())
            System.out.println("invalid command!");
        else {
            Integer amount = Integer.valueOf(matcherSetDiscount.group(2));
            String code = matcherSetDiscount.group(3);
            if (!LoginMenu.allUsers.containsKey(username))
                System.out.println("set discount failed: username not found");
            else if (amount <= 0)
                System.out.println("set discount failed: invalid amount");
            else if (!Commands.getMatcher(code, Commands.DISCOUNT_VALIDATION).find())
                System.out.println("set discount failed: invalid code format");
            else {
                SnappFoodManager.setDiscount(username, amount, code);
                System.out.println("set discount successful");
            }
        }
    }

    public void showDiscountForAdmin()
    {
        SnappFoodManager.showDiscounts();
    }
}
