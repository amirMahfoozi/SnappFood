package model;

import java.util.Vector;

public class RestaurantManager {
    private Restaurant restaurant;
    private String username;
    private String password;
    private static Vector<RestaurantManager> allRestaurantManager = new Vector<>();

    public RestaurantManager(Restaurant restaurant, String username, String password) {
        this.restaurant = restaurant;
        this.password = password;
        this.username = username;
        allRestaurantManager.add(this);

    }

    public static void removeAccount(String username) {
        for (int i = 0; i < allRestaurantManager.size(); i++) {
            if (allRestaurantManager.get(i).username.equals(username)) {
                allRestaurantManager.remove(i);
                break;
            }
        }
    }

    public static void ChangePassword(String username, String password) {
        for (int i = 0; i < allRestaurantManager.size(); i++) {
            if (allRestaurantManager.get(i).username.equals(username)) {
                allRestaurantManager.get(i).password = password;
                allRestaurantManager.get(i).restaurant.setPassword(password);
                break;
            }
        }
    }

    public static void chargeAccount(String username, Integer amount) {
        for (int i = 0; i < allRestaurantManager.size(); i++) {
            if (allRestaurantManager.get(i).username.equals(username)) {
                allRestaurantManager.get(i).restaurant.changeBalance(amount);
                break;
            }
        }
    }

    public static void showBalance(String username) {
        for (int i = 0; i < allRestaurantManager.size(); i++) {
            if (allRestaurantManager.get(i).username.equals(username)) {
                System.out.println(allRestaurantManager.get(i).restaurant.getBalance());
                break;
            }
        }
    }

    public static void addFood(String username, String name, String category, Integer cost, Integer price) {
        Food food = new Food(name, category, cost, price);
        for (int i = 0; i < allRestaurantManager.size(); i++) {
            if (allRestaurantManager.get(i).username.equals(username)) {
                allRestaurantManager.get(i).restaurant.addFood(food);
                break;
            }
        }
    }

    public static boolean IsFoodAvailable(String username, String name) {
        for (int i = 0; i < allRestaurantManager.size(); i++) {
            if (allRestaurantManager.get(i).username.equals(username)) {
                for (int j = 0; j < allRestaurantManager.get(i).restaurant.getAllFoods().size(); j++) {
                    if (allRestaurantManager.get(i).restaurant.getAllFoods().get(j).getName().equals(name))
                        return true;
                }
            }
        }
        return false;
    }

    public static void removeFood(String username, String name) {
        boolean found = false;
        for (int i = 0; i < allRestaurantManager.size(); i++) {
            if (allRestaurantManager.get(i).username.equals(username)) {
                for (int j = 0; j < allRestaurantManager.get(i).restaurant.getAllFoods().size(); j++) {
                    if (allRestaurantManager.get(i).restaurant.getAllFoods().get(j).getName().equals(name)) {
                        allRestaurantManager.get(i).restaurant.getAllFoods().remove(j);
                        found = true;
                        break;
                    }
                }
            }
        }
        if (!found)
            System.out.println("remove food failed: food not found");
    }
}
