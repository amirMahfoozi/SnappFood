package model;

import java.util.HashMap;
import java.util.Vector;

public class Customer {
    private String username;
    private String password;
    private Integer balance;
    private static HashMap<String, Customer> allCustomers = new HashMap<>(); // username -> customer
    private Vector<Discount> allDiscounts = new Vector<>();
    private Vector<Order> cart = new Vector<>();

    public Customer(String username, String password) {
        this.username = username;
        this.password = password;
        this.balance = 0;
        allCustomers.put(username, this);
    }

    private void setPassword(String password) {
        this.password = password;
    }

    public static void changePassword(String username, String newPass) {
        allCustomers.get(username).setPassword(newPass);
    }

    public static void RemoveAccount(String username) {
        allCustomers.remove(username);
    }

    public static boolean isUsernameCustomer(String username) {
        return allCustomers.containsKey(username);
    }

    public Vector<Discount> getAllDiscounts() {
        return allDiscounts;
    }

    public static void addDiscount(String username, Discount discount) {
        allCustomers.get(username).getAllDiscounts().add(discount);
    }

    public static void showAllDiscount(String username) {
        for (int i = 0; i < allCustomers.get(username).getAllDiscounts().size(); i++) {
            System.out.println((i + 1) + ") " + allCustomers.get(username).getAllDiscounts().get(i).getCodeName() + " | amount=" + allCustomers.get(username).getAllDiscounts().get(i).getAmount());
        }
    }

    public static void changeBalance(String username, Integer amount) {
        allCustomers.get(username).balance += amount;
    }

    public static void showBalance(String username) {
        System.out.println(allCustomers.get(username).balance);
    }

    public static void showRestaurants(String type) {
        if (type == null) {
            for (int i = 0; i < Restaurant.getAllRestaurants().size(); i++) {
                System.out.println((i + 1) + ") " + Restaurant.getAllRestaurants().get(i).getName() + ": type=" + Restaurant.getAllRestaurants().get(i).getType());
            }
        } else {
            int cnt = 1;
            for (int i = 0; i < Restaurant.getAllRestaurants().size(); i++) {
                if (type.equals(Restaurant.getAllRestaurants().get(i).getType())) {
                    System.out.println(cnt + ") " + Restaurant.getAllRestaurants().get(i).getName() + ": type=" + Restaurant.getAllRestaurants().get(i).getType());
                    cnt++;
                }
            }
        }
    }

    public static void showMenu(Restaurant restaurant, String category) {
        if (category == null) {
            System.out.println("<< STARTER >>");
            for (int i = 0; i < restaurant.getAllFoods().size(); i++) {
                if (restaurant.getAllFoods().get(i).getCategory().equals("starter"))
                    System.out.println(restaurant.getAllFoods().get(i).getName() + " | price=" + restaurant.getAllFoods().get(i).getPrice());
            }
            System.out.println("<< ENTREE >>");
            for (int i = 0; i < restaurant.getAllFoods().size(); i++) {
                if (restaurant.getAllFoods().get(i).getCategory().equals("entree"))
                    System.out.println(restaurant.getAllFoods().get(i).getName() + " | price=" + restaurant.getAllFoods().get(i).getPrice());
            }
            System.out.println("<< DESSERT >>");
            for (int i = 0; i < restaurant.getAllFoods().size(); i++) {
                if (restaurant.getAllFoods().get(i).getCategory().equals("dessert"))
                    System.out.println(restaurant.getAllFoods().get(i).getName() + " | price=" + restaurant.getAllFoods().get(i).getPrice());
            }
        } else {
            if (category.equals("starter")) {
                for (int i = 0; i < restaurant.getAllFoods().size(); i++) {
                    if (restaurant.getAllFoods().get(i).getCategory().equals("starter"))
                        System.out.println(restaurant.getAllFoods().get(i).getName() + " | price=" + restaurant.getAllFoods().get(i).getPrice());
                }
            } else if (category.equals("entree")) {
                for (int i = 0; i < restaurant.getAllFoods().size(); i++) {
                    if (restaurant.getAllFoods().get(i).getCategory().equals("entree"))
                        System.out.println(restaurant.getAllFoods().get(i).getName() + " | price=" + restaurant.getAllFoods().get(i).getPrice());
                }
            } else if (category.equals("dessert")) {
                for (int i = 0; i < restaurant.getAllFoods().size(); i++) {
                    if (restaurant.getAllFoods().get(i).getCategory().equals("dessert"))
                        System.out.println(restaurant.getAllFoods().get(i).getName() + " | price=" + restaurant.getAllFoods().get(i).getPrice());
                }
            } else if (!Commands.getMatcher(category, Commands.CATEGORY_VALIDATION).find())
                System.out.println("show menu failed: invalid category");
        }
    }

    public static void addToCart(String username, Order order) {
        if (IsOrderInCart(username, order.getRestaurant().getName(), order.getFood().getName()) == null)
            allCustomers.get(username).cart.add(order);
        else {
            IsOrderInCart(username, order.getRestaurant().getName(), order.getFood().getName()).setNumber(IsOrderInCart(username, order.getRestaurant().getName(), order.getFood().getName()).getNumber() + order.getNumber());
        }
    }

    public static Order IsOrderInCart(String username, String restaurantName, String foodName) {
        for (int i = 0; i < allCustomers.get(username).cart.size(); i++) {
            if (allCustomers.get(username).cart.get(i).getFood().getName().equals(foodName) && allCustomers.get(username).cart.get(i).getRestaurant().getName().equals(restaurantName)) {
                return allCustomers.get(username).cart.get(i);
            }
        }
        return null;
    }

    public static void removeFromCart(String username, String restaurantName, String foodName, Integer numberOfRemove) {
        for (int i = 0; i < allCustomers.get(username).cart.size(); i++) {
            if (allCustomers.get(username).cart.get(i).getFood().getName().equals(foodName) && allCustomers.get(username).cart.get(i).getRestaurant().getName().equals(restaurantName)) {
                if (allCustomers.get(username).cart.get(i).getNumber() - numberOfRemove == 0) {
                    allCustomers.get(username).cart.remove(i);
                    i--;
                }
                else
                    allCustomers.get(username).cart.get(i).setNumber(allCustomers.get(username).cart.get(i).getNumber() - numberOfRemove);
            }
        }
    }

    public static void showCart(String username) {
        Integer totalAmount = 0;
        for (int i = 0; i < allCustomers.get(username).cart.size(); i++) {
            totalAmount += allCustomers.get(username).cart.get(i).getFood().getPrice() * allCustomers.get(username).cart.get(i).getNumber();
            System.out.println((i + 1) + ") " + allCustomers.get(username).cart.get(i).getFood().getName() + " | restaurant=" + allCustomers.get(username).cart.get(i).getRestaurant().getName() + " price=" + allCustomers.get(username).cart.get(i).getFood().getPrice() * allCustomers.get(username).cart.get(i).getNumber());
        }
        System.out.println("Total: " + totalAmount);
    }

    public static void purchase(String username, String discountCode) {
        Integer discountValue = 0;
        if (discountCode != null) {
            boolean found = false;
            for (int i = 0; i < allCustomers.get(username).allDiscounts.size(); i++) {
                if (allCustomers.get(username).allDiscounts.get(i).getCodeName().equals(discountCode)) {
                    found = true;
                    discountValue = allCustomers.get(username).allDiscounts.get(i).getAmount();
                    allCustomers.get(username).allDiscounts.remove(i);
                    SnappFoodManager.removeDiscount(username, discountCode);
                    break;
                }
            }
            if (!found)
                System.out.println("purchase failed: invalid discount code");
            else {
                Integer totalAmount = 0;
                for (int i = 0; i < allCustomers.get(username).cart.size(); i++) {
                    totalAmount += allCustomers.get(username).cart.get(i).getFood().getPrice() * allCustomers.get(username).cart.get(i).getNumber();
                }
                totalAmount -= discountValue;
                if (totalAmount > allCustomers.get(username).balance)
                    System.out.println("purchase failed: inadequate money");
                else {
                    allCustomers.get(username).balance -= totalAmount;
                    for (int i = 0; i < allCustomers.get(username).cart.size(); i++) {
                        allCustomers.get(username).cart.get(i).getRestaurant().changeBalance(allCustomers.get(username).cart.get(i).getFood().getPrice() * allCustomers.get(username).cart.get(i).getNumber());
                        allCustomers.get(username).cart.get(i).getRestaurant().changeBalance(-allCustomers.get(username).cart.get(i).getFood().getCost() * allCustomers.get(username).cart.get(i).getNumber());
                    }
                    System.out.println("purchase successful");
                    allCustomers.get(username).cart.clear();
                }
            }
        } else {
            Integer totalAmount = 0;
            for (int i = 0; i < allCustomers.get(username).cart.size(); i++) {
                totalAmount += allCustomers.get(username).cart.get(i).getFood().getPrice() * allCustomers.get(username).cart.get(i).getNumber();
            }
            if (totalAmount > allCustomers.get(username).balance)
                System.out.println("purchase failed: inadequate money");
            else {
                allCustomers.get(username).balance -= totalAmount;
                for (int i = 0; i < allCustomers.get(username).cart.size(); i++) {
                    allCustomers.get(username).cart.get(i).getRestaurant().changeBalance(allCustomers.get(username).cart.get(i).getFood().getPrice() * allCustomers.get(username).cart.get(i).getNumber());
                    allCustomers.get(username).cart.get(i).getRestaurant().changeBalance(-allCustomers.get(username).cart.get(i).getFood().getCost() * allCustomers.get(username).cart.get(i).getNumber());

                }
                allCustomers.get(username).cart.clear();
                System.out.println("purchase successful");
            }
        }
    }
}
