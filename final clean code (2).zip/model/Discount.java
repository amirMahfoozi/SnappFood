package model;

public class Discount {
    private String codeName;
    private Integer amount;

    public Discount(String codeName, Integer amount) {
        this.amount = amount;
        this.codeName = codeName;
    }

    public Integer getAmount() {
        return amount;
    }

    public String getCodeName() {
        return codeName;
    }
}
