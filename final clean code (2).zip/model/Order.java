package model;

public class Order {
    private Restaurant restaurant;
    private Food food;
    private Integer number;

    public Order(Restaurant restaurant, Food food, Integer number) {
        this.number = number;
        this.restaurant = restaurant;
        this.food = food;
    }

    public Food getFood() {
        return food;
    }

    public Integer getNumber() {
        return number;
    }

    public Restaurant getRestaurant() {
        return restaurant;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }
}
