package model;

import java.util.Vector;

public class Restaurant {
    private String name;
    private String password;
    private String type;
    private Integer balance;
    private static Vector<String> allRestaurantsNames = new Vector<>();
    private static Vector<Restaurant> allRestaurants = new Vector<>();
    private Vector<Food> allFoods = new Vector<>();

    //private HashMap<String,Food> allFoods = new HashMap<>(); // foodName --> Food
    public Restaurant(String name, String password, String type) {
        this.name = name;
        this.password = password;
        this.type = type;
        this.balance = 0;
        allRestaurantsNames.add(name);
        allRestaurants.add(this);
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public static Vector<Restaurant> getAllRestaurants() {
        return allRestaurants;
    }

    public static Vector<String> getAllRestaurantsNames() {
        return allRestaurantsNames;
    }

    public void changeBalance(Integer amount) {
        this.balance += amount;
    }

    public Integer getBalance() {
        return balance;
    }

    public void addFood(Food food) {
        this.allFoods.add(food);
    }

    public Vector<Food> getAllFoods() {
        return allFoods;
    }

    public void removeFood(String foodName) {
        for (int i = 0; i < this.allFoods.size(); i++) {
            if (this.allFoods.get(i).getName().equals(foodName)) {
                this.allFoods.remove(i);
                break;
            }
        }
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public static void removeRestaurant(String name) {
        for (int i = 0; i < allRestaurantsNames.size(); i++) {
            if (allRestaurantsNames.get(i).equals(name)) {
                allRestaurantsNames.remove(i);
                allRestaurants.remove(i);
                break;
            }
        }
    }

    public static Restaurant findRestaurantByName(String name) {
        for (int i = 0; i < allRestaurants.size(); i++) {
            if (allRestaurants.get(i).getName().equals(name))
                return allRestaurants.get(i);
        }
        return null;
    }

    public Food findFoodByName(String name) {
        for (int i = 0; i < this.allFoods.size(); i++) {
            if (this.allFoods.get(i).getName().equals(name))
                return this.allFoods.get(i);
        }
        return null;
    }
}
