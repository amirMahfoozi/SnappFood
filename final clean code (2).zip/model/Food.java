package model;

public class Food {
    private String name;
    private String category;
    private Integer cost;
    private Integer price;

    public Food(String name, String category, Integer cost, Integer price) {
        this.category = category;
        this.name = name;
        this.cost = cost;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public Integer getPrice() {
        return price;
    }

    public String getCategory() {
        return category;
    }

    public Integer getCost() {
        return cost;
    }
}
