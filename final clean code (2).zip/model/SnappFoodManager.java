package model;

import java.util.Vector;

public class SnappFoodManager {
    public static SnappFoodManager manager;
    private String username;
    private String password;
    private static Vector<String> allDiscountsGivenUsername = new Vector<>();
    private static Vector<Discount> allDiscountsGivenDiscount = new Vector<>();

    public SnappFoodManager(String username, String password) {
        this.username = username;
        this.password = password;
        manager = this;
    }

    public String getPassword() {
        return password;
    }

    public static void changePassword(String newPassword) {
        manager.password = newPassword;
    }

    public String getUsername() {
        return username;
    }

    public static void showRestaurants(String type) {
        if (type == null) {
            for (int i = 0; i < Restaurant.getAllRestaurants().size(); i++) {
                System.out.println((i + 1) + ") " + Restaurant.getAllRestaurants().get(i).getName() + ": type=" + Restaurant.getAllRestaurants().get(i).getType() + " balance=" + Restaurant.getAllRestaurants().get(i).getBalance());
            }
        } else {
            int cnt = 1;
            for (int i = 0; i < Restaurant.getAllRestaurants().size(); i++) {
                if (type.equals(Restaurant.getAllRestaurants().get(i).getType())) {
                    System.out.println(cnt + ") " + Restaurant.getAllRestaurants().get(i).getName() + ": type=" + Restaurant.getAllRestaurants().get(i).getType() + " balance=" + Restaurant.getAllRestaurants().get(i).getBalance());
                    cnt++;
                }
            }
        }
    }

    public static void setDiscount(String username, Integer amount, String code) {
        Discount discount = new Discount(code, amount);
        Customer.addDiscount(username, discount);
        allDiscountsGivenUsername.add(username);
        allDiscountsGivenDiscount.add(discount);
    }

    public static void showDiscounts() {

        for (int i = 0; i < allDiscountsGivenDiscount.size(); i++) {
            System.out.println((i + 1) + ") " + allDiscountsGivenDiscount.get(i).getCodeName() + " | amount=" + allDiscountsGivenDiscount.get(i).getAmount() + " --> user=" + allDiscountsGivenUsername.get(i));
        }
    }

    public static void removeDiscount(String username, String discountCode) {
        for (int i = 0; i < allDiscountsGivenDiscount.size(); i++) {
            if (allDiscountsGivenDiscount.get(i).getCodeName().equals(discountCode) && allDiscountsGivenUsername.get(i).equals(username)) {
                allDiscountsGivenUsername.remove(i);
                allDiscountsGivenDiscount.remove(i);
                break;
            }
        }
    }
}
