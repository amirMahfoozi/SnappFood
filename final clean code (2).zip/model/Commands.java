package model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum Commands {
    SHOW_CURRENT_MENU("^\\s*show\\s+current\\s+menu\\s*$"),
    REGISTER("^\\s*register\\s+(\\S+)\\s+(\\S+)\\s*$"),
    USERNAME_VALIDATION("^(?=.*[A-Za-z])[a-zA-Z0-9_]{0,}$"),
    STRONG_PASSWORD("^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{5,}$"),
    PASSWORD_VALIDATION("^\\w+$"),
    EXIT("^\\s*exit\\s*$"),
    LOGIN("^\\s*login\\s+(\\S+)\\s+(\\S+)\\s*$"),
    CHANGE_PASSWORD("^\\s*change\\s+password\\s+(\\S+)\\s+(\\S+)\\s+(\\S+)\\s*$"),
    REMOVE_ACCOUNT("^\\s*remove\\s+account\\s+(\\S+)\\s+(\\S+)\\s*$"),
    ENTER_MENU("^\\s*enter\\s+(.+?)\\s*$"),
    LOGOUT("^\\s*logout\\s*$"),
    ADD_RESTAURANT("^\\s*add\\s+restaurant\\s+(\\S+)\\s+(\\S+)\\s+(\\S+)\\s*$"),
    TYPE_VALIDATION("^[a-z\\-]+$"),
    SHOW_RESTAURANT("^\\s*show\\s+restaurant\\s*(-t\\s+(\\S+))?\\s*$"),
    REMOVE_RESTAURANT("^\\s*remove\\s+restaurant\\s+(\\S+)\\s*$"),
    SET_DISCOUNT("^\\s*set\\s+discount\\s+(\\S+)\\s+(\\S+)\\s+(\\S+)\\s*$"),
    DISCOUNT_VALIDATION("^[A-Za-z0-9]+$"),
    SHOW_DISCOUNT("^\\s*show\\s+discounts\\s*$"),
    CHARGE_ACCOUNT("^\\s*charge\\s+account\\s+(\\S+)\\s*$"),
    SHOW_BALANCE("^\\s*show\\s+balance\\s*$"),
    ADD_FOOD("^\\s*add\\s+food\\s+(\\S+)\\s+(\\S+)\\s+(\\S+)\\s+(\\S+)\\s*$"),
    CATEGORY_VALIDATION("^(starter|entree|dessert){1}$"),
    FOODNAME_VALIDATION("^[a-z-]+$"),
    REMOVE_FOOD("^\\s*remove\\s+food\\s+(\\S+)\\s*$"),
    SHOW_MENU("^\\s*show\\s+menu\\s+(\\S+)\\s*(-c\\s+(\\S+))?\\s*$"),
    ADD_TO_CART("^\\s*add\\s+to\\s+cart\\s+(\\S+)\\s+(\\S+)\\s*(-n\\s+(\\S+))?\\s*$"),
    REMOVE_FROM_CART("^\\s*remove\\s+from\\s+cart\\s+(\\S+)\\s+(\\S+)\\s*(-n\\s+(\\S+))?\\s*$"),
    SHOW_CART("^\\s*show\\s+cart\\s*$"),
    PURCHASE("^\\s*purchase\\s+cart\\s*(-d\\s+(\\S+))?\\s*$"),
    IS_NUMBER("^\\-?\\d+$");

    private String regex;

    Commands(String regex) {
        this.regex = regex;
    }

    public static Matcher getMatcher(String input, Commands command) {
        Pattern pattern = Pattern.compile(command.regex);
        return pattern.matcher(input);
    }
}
