package view;

import controller.Controller;
import model.*;

import java.util.HashMap;
import java.util.regex.Matcher;

public class LoginMenu {
    private Controller controller;
    public static String currentUsername; // logged in user
    public static String currentPassword;
    public static HashMap<String, String> allUsers = new HashMap<>(); // username -> password

    public LoginMenu(Controller controller) {
        this.controller = controller;
    }

    public String run() {
        String line = Menu.getScanner().nextLine();
        while (true) {
            //commands matchers
            Matcher matcherRegister = Commands.getMatcher(line, Commands.REGISTER);
            Matcher matcherLogin = Commands.getMatcher(line, Commands.LOGIN);
            Matcher matcherChangePassword = Commands.getMatcher(line, Commands.CHANGE_PASSWORD);
            Matcher matcherRemoveAccount = Commands.getMatcher(line, Commands.REMOVE_ACCOUNT);

            if (Commands.getMatcher(line, Commands.EXIT).find())
                System.exit(0);
            else if (matcherRegister.find()) {
                controller.register(matcherRegister,allUsers);
            } else if (matcherLogin.find()) {
                String username = matcherLogin.group(1);
                String password = matcherLogin.group(2);
                if(controller.login(matcherLogin,allUsers) != null)
                {
                    currentUsername = username;
                    currentPassword = password;
                    return "login successful";
                }
            } else if (matcherChangePassword.find()) {
                controller.changePassword(matcherChangePassword,allUsers);
            } else if (matcherRemoveAccount.find()) {
               controller.removeAccount(matcherRemoveAccount,allUsers);
            } else if (Commands.getMatcher(line, Commands.SHOW_CURRENT_MENU).find()) {
                System.out.println("login menu");
            } else {
                System.out.println("invalid command!");
            }
            line = Menu.getScanner().nextLine();
        }
    }
}
