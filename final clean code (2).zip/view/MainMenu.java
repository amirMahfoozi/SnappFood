package view;

import controller.Controller;
import model.Commands;

import java.util.regex.Matcher;

public class MainMenu {
    private Controller controller;

    public MainMenu(Controller controller) {
        this.controller = controller;
    }

    public String run() {
        String type = controller.usernameType();
        String line = Menu.getScanner().nextLine();
        while (true) {
            Matcher matcherEnter = Commands.getMatcher(line, Commands.ENTER_MENU);
            if (matcherEnter.find()) {
                if(controller.enterMenu(matcherEnter,type) != null)
                    return matcherEnter.group(1);
            } else if (Commands.getMatcher(line, Commands.LOGOUT).find()) {
                return "logged out";
            } else if (Commands.getMatcher(line, Commands.SHOW_CURRENT_MENU).find()) {
                System.out.println("main menu");
            } else {
                System.out.println("invalid command!");
            }
            line = Menu.getScanner().nextLine();
        }
    }
}
