package view;

import controller.Controller;
import model.*;

import java.util.regex.Matcher;

public class CustomerMenu {
    private Controller controller;

    public CustomerMenu(Controller controller) {
        this.controller = controller;
    }

    public String run() {
        String currentUsername = LoginMenu.currentUsername;
        String line = Menu.getScanner().nextLine();
        while (true) {
            Matcher matcherChargeAccount = Commands.getMatcher(line, Commands.CHARGE_ACCOUNT);
            Matcher matcherShowBalance = Commands.getMatcher(line, Commands.SHOW_BALANCE);
            Matcher matcherShowRestaurant = Commands.getMatcher(line, Commands.SHOW_RESTAURANT);
            Matcher matcherShowMenu = Commands.getMatcher(line, Commands.SHOW_MENU);
            Matcher matcherAddToCart = Commands.getMatcher(line, Commands.ADD_TO_CART);
            Matcher matcherRemoveFromCart = Commands.getMatcher(line, Commands.REMOVE_FROM_CART);
            Matcher matcherShowDiscount = Commands.getMatcher(line, Commands.SHOW_DISCOUNT);
            Matcher matcherShowCart = Commands.getMatcher(line, Commands.SHOW_CART);
            Matcher matcherPurchase = Commands.getMatcher(line, Commands.PURCHASE);
            if (matcherChargeAccount.find()) {
                controller.chargeAccount(matcherChargeAccount,currentUsername);
            } else if (matcherShowBalance.find()) {
                controller.showBalance(currentUsername);
            } else if (matcherShowRestaurant.find()) {
                controller.showRestaurant(matcherShowRestaurant);
            } else if (matcherShowMenu.find()) {
                controller.showMenu(matcherShowMenu);
            } else if (matcherAddToCart.find()) {
                controller.addToCart(matcherAddToCart,currentUsername);
            } else if (matcherRemoveFromCart.find()) {
                controller.removeFromCart(matcherRemoveFromCart,currentUsername);
            } else if (matcherShowCart.find()) {
                controller.showCart(currentUsername);
            } else if (matcherShowDiscount.find()) {
                controller.showAllDiscount(currentUsername);
            } else if (matcherPurchase.find()) {
                controller.purchase(matcherPurchase,currentUsername);
            } else if (Commands.getMatcher(line, Commands.SHOW_CURRENT_MENU).find()) {
                System.out.println("customer menu");
            } else if (Commands.getMatcher(line, Commands.LOGOUT).find()) {
                return "logged out";
            } else {
                System.out.println("invalid command!");
            }
            line = Menu.getScanner().nextLine();
        }
    }
}
