package view;

import controller.Controller;
import model.*;

import java.util.regex.Matcher;

public class SnappfoodAdminMenu {
    private Controller controller;

    public SnappfoodAdminMenu(Controller controller) {
        this.controller = controller;
    }

    public String run() {
        String line = Menu.getScanner().nextLine();
        while (true) {
            Matcher matcherAddRestaurant = Commands.getMatcher(line, Commands.ADD_RESTAURANT);
            Matcher matcherShowRestaurant = Commands.getMatcher(line, Commands.SHOW_RESTAURANT);
            Matcher matcherRemoveRestaurant = Commands.getMatcher(line, Commands.REMOVE_RESTAURANT);
            Matcher matcherSetDiscount = Commands.getMatcher(line, Commands.SET_DISCOUNT);
            Matcher matcherShowDiscount = Commands.getMatcher(line, Commands.SHOW_DISCOUNT);
            if (matcherAddRestaurant.find()) {
                controller.addRestaurant(matcherAddRestaurant);
            } else if (matcherShowRestaurant.find()) {
                controller.showRestaurantForManager(matcherShowRestaurant);
            } else if (matcherRemoveRestaurant.find()) {
                controller.removeRestaurant(matcherRemoveRestaurant);
            } else if (matcherSetDiscount.find()) {
                controller.setDiscount(matcherSetDiscount);
            } else if (matcherShowDiscount.find()) {
                controller.showDiscountForAdmin();
            } else if (Commands.getMatcher(line, Commands.LOGOUT).find()) {
                return "logged out";
            } else if (Commands.getMatcher(line, Commands.SHOW_CURRENT_MENU).find()) {
                System.out.println("Snappfood admin menu");
            } else if (Commands.getMatcher(line, Commands.LOGOUT).find()) {
                return "logged out";
            } else {
                System.out.println("invalid command!");
            }
            line = Menu.getScanner().nextLine();
        }
    }
}
