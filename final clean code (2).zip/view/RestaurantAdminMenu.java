package view;

import controller.Controller;
import model.Commands;

import java.util.regex.Matcher;

public class RestaurantAdminMenu {
    private Controller controller;

    public RestaurantAdminMenu(Controller controller) {
        this.controller = controller;
    }

    public String run() {
        String currentUsername = LoginMenu.currentUsername;
        String line = Menu.getScanner().nextLine();
        while (true) {
            Matcher matcherChargeAccount = Commands.getMatcher(line, Commands.CHARGE_ACCOUNT);
            Matcher matcherShowBalance = Commands.getMatcher(line, Commands.SHOW_BALANCE);
            Matcher matcherAddFood = Commands.getMatcher(line, Commands.ADD_FOOD);
            Matcher matcherRemoveFood = Commands.getMatcher(line, Commands.REMOVE_FOOD);
            if (matcherChargeAccount.find()) {
                controller.chargeRestaurantAccount(matcherChargeAccount,currentUsername);
            } else if (matcherShowBalance.find()) {
                controller.showRestaurantBalance(currentUsername);
            } else if (matcherAddFood.find()) {
                controller.addFood(matcherAddFood,currentUsername);
            } else if (matcherRemoveFood.find()) {
                controller.removeFood(matcherRemoveFood,currentUsername);
            } else if (Commands.getMatcher(line, Commands.SHOW_CURRENT_MENU).find()) {
                System.out.println("restaurant admin menu");
            } else if (Commands.getMatcher(line, Commands.LOGOUT).find()) {
                return "logged out";
            } else {
                System.out.println("invalid command!");
            }
            line = Menu.getScanner().nextLine();
        }
    }
}
