package view;

import java.util.Scanner;

public class Menu {
    private static final Scanner scanner = new Scanner(System.in);

    public static Scanner getScanner() {
        return scanner;
    }

    public static String usernameSnappFoodManager = Menu.getScanner().nextLine();
    public static String passwordSnappFoodManager = Menu.getScanner().nextLine();
}
